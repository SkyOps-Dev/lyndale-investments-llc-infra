import boto3

def lambda_handler(event, context):
    # Print Hello World
    print("Hello, World!")
